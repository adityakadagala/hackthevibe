package com.vibecraftcrew.projectmanagement.auth;

public record AuthResponse(String token, String tokenType) {}