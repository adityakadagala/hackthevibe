package com.vibecraftcrew.projectmanagement.auth;

public record LoginRequest(String email, String password) {}